---
name: Price Action Master
colors:
  surface: '#0f1413'
  surface-dim: '#0f1413'
  surface-bright: '#353a39'
  surface-container-lowest: '#0a0f0e'
  surface-container-low: '#181d1b'
  surface-container: '#1c211f'
  surface-container-high: '#262b2a'
  surface-container-highest: '#313635'
  on-surface: '#dfe3e1'
  on-surface-variant: '#bac9cc'
  inverse-surface: '#dfe3e1'
  inverse-on-surface: '#2c3130'
  outline: '#849396'
  outline-variant: '#3b494c'
  surface-tint: '#00daf3'
  primary: '#c3f5ff'
  on-primary: '#00363d'
  primary-container: '#00e5ff'
  on-primary-container: '#00626e'
  inverse-primary: '#006875'
  secondary: '#e9c176'
  on-secondary: '#412d00'
  secondary-container: '#604403'
  on-secondary-container: '#dab36a'
  tertiary: '#ffe7e6'
  on-tertiary: '#680015'
  tertiary-container: '#ffc1c1'
  on-tertiary-container: '#b3082d'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#9cf0ff'
  primary-fixed-dim: '#00daf3'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#004f58'
  secondary-fixed: '#ffdea5'
  secondary-fixed-dim: '#e9c176'
  on-secondary-fixed: '#261900'
  on-secondary-fixed-variant: '#5d4201'
  tertiary-fixed: '#ffdad9'
  tertiary-fixed-dim: '#ffb3b3'
  on-tertiary-fixed: '#400009'
  on-tertiary-fixed-variant: '#920021'
  background: '#0f1413'
  on-background: '#dfe3e1'
  surface-variant: '#313635'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  title-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  label-caps:
    fontFamily: Geist
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.1em
  mono-data:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 48px
  container-max: 1280px
---

## Brand & Style
The design system is engineered for high-stakes clarity and professional authority. It adopts a **Terminal Minimalism** aesthetic—blending the density of a trading dashboard with the refined breathing room of a luxury educational platform. 

The UI prioritizes "Information Density without Clutter," utilizing a technical drawing style characterized by precise lines, mathematical precision, and a high-contrast dark environment. The target audience includes serious traders who value efficiency, accuracy, and a focused learning environment free from consumer-grade "gamification" distractions.

## Colors
This design system operates on a multi-layered dark palette to ensure depth in a low-light environment.

*   **Core Background:** The deepest layer is a dark slate (#0C1110), providing a non-fatiguing backdrop for long study sessions.
*   **Primary Accent (Signal Cyan):** Used for "Buy" signals, progress indicators, and active states. It represents liquidity and movement.
*   **Secondary Accent (Trade Gold):** Reserved for "Mastery" elements, premium features, and successful milestone markers. 
*   **Semantic Accents:** A sharp Maroon/Red (#FF4B5C) is used for "Sell" signals, risk warnings, and downward price action.
*   **Neutral Palette:** Grays are tinted with slate to maintain a cohesive atmospheric temperature.

## Typography
The typography system utilizes **Inter** for its exceptional legibility in data-dense layouts. For technical data, price tickers, and terminal-style labels, **Geist** is introduced to provide a monospaced, developer-centric feel that reinforces the "technical drawing" aesthetic.

*   **Hierarchy:** Use `display-lg` for market summaries and module titles.
*   **Data Labels:** `label-caps` should be used above charts or for secondary metadata to differentiate from instructional body text.
*   **Contrast:** Headlines should always be Pure White (#FFFFFF) or Signal Cyan, while body text should be kept at 85% opacity (Slate 200) to reduce eye strain.

## Layout & Spacing
The spacing rhythm follows a strict **4px baseline grid**. Layouts should feel structured and modular, mimicking a professional trading station.

*   **Grid:** Use a 12-column grid for desktop with 24px gutters. For the "Market Dashboard" view, a 16-column grid is permissible to allow for narrow sidebars containing watchlists and tickers.
*   **Padding:** Card containers should utilize 24px internal padding for desktop and 16px for mobile.
*   **Modular Reflow:** On mobile, sidebars collapse into a bottom-anchored "Market Bar." Educational content (video/text) takes priority, with technical tools accessible via floating action layers.

## Elevation & Depth
This design system avoids traditional drop shadows in favor of **Tonal Layering** and **Luminous Outlines**.

*   **Surface Hierarchy:**
    *   **Level 0 (#0C1110):** Main background.
    *   **Level 1 (#161D1C):** Main content cards and navigation sidebars.
    *   **Level 2 (#1C2524):** Hover states, input fields, and nested UI elements.
*   **Borders:** Depth is defined by 1px solid borders using `border_color_hex`. High-priority cards use a subtle "inner glow" via a cyan-tinted top border.
*   **Glassmorphism:** Use sparingly for navigation overlays or "Price Ticker" bars, using a 12px backdrop blur and 10% white opacity.

## Shapes
The shape language is "Soft-Technical." Elements use a **4px radius (Soft)** to maintain a modern look while appearing more precise and "engineered" than the bubbly consumer-standard rounded corners. 

*   **Buttons:** Standard buttons use 4px radius.
*   **Indicators:** Market trend indicators (up/down arrows) should be sharp and geometric, not rounded.
*   **Graph Points:** Small circles (no radius) or technical crosses (+) should be used for chart annotations.

## Components
*   **Buttons:** 
    *   *Primary:* Solid Cyan with black text. No shadow; high-contrast.
    *   *Secondary:* Outlined with 1px Trade Gold border.
*   **Technical Cards:** Dark slate background with a 1px border. For "Win/Loss" result boxes, use a subtle 5% background tint of Cyan (Win) or Maroon (Loss) to fill the card.
*   **Input Fields:** Ghost-style. No fill, only a bottom border or 1px stroke that glows Cyan on focus.
*   **Chips/Labels:** Use the `label-caps` typography style. Backgrounds should be low-opacity versions of the primary/secondary colors.
*   **Trade Terminal Boxes:** Specialized display boxes with monospaced data. Ticks and live pricing should use a high-contrast flicker effect when updating.
*   **Icons:** Thin-stroke (1.5px) geometric icons. Avoid filled icons to maintain the technical drawing feel.